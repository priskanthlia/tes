package kuispbo;

import javax.swing.*;
import java.awt.*;

public class CheckoutPage extends JFrame {
    public CheckoutPage(String nama, String gender, String genre, int quantity, int totalPrice) {
        setTitle("Checkout Page");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // Format pesan checkout
        String message = String.format(
                "Booking Confirmation:\n\nName: %s\nGender: %s\nGenre: %s\nquantity: %d\nTotal Price: $%d",
                nama, gender, genre, quantity, totalPrice
        );
        
        // Label untuk menampilkan informasi
        JTextArea messageArea = new JTextArea(message);
        messageArea.setEditable(false);
        messageArea.setFont(new Font("Arial", Font.PLAIN, 14));
        messageArea.setMargin(new Insets(10, 10, 10, 10));
        
        add(new JScrollPane(messageArea), BorderLayout.CENTER);
        
        setVisible(true);
    }
}

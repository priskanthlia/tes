/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kuispbo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PurchasePage extends JFrame {
    private String category;
    private int pricePerUnit;
    private JTextField quantityField;
    private JLabel totalLabel, unitPriceLabel, quantityLabel, taxLabel, finalTotalLabel;
    private MainPage mainPage;

    public PurchasePage(MainPage mainPage, String category, int pricePerUnit) {
        this.mainPage = mainPage;
        this.category = category;
        this.pricePerUnit = pricePerUnit;

        setSize(400, 550);
        setTitle("Halaman Pembelian");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Menyembunyikan MainPage
        mainPage.setVisible(false);

        JLabel titleLabel = new JLabel("Halaman Pembelian", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setBounds(0, 20, getWidth(), 30);

        JLabel categoryLabel = new JLabel("Kategori: " + category);
        categoryLabel.setBounds(50, 60, 300, 30);

        JLabel priceLabel = new JLabel("Harga per pcs: Rp " + pricePerUnit);
        priceLabel.setBounds(50, 90, 300, 30);

        JLabel quantityTextLabel = new JLabel("Jumlah:");
        quantityTextLabel.setBounds(50, 120, 100, 30);

        quantityField = new JTextField();
        quantityField.setBounds(160, 120, 100, 30);

        JButton buyButton = new JButton("Beli");
        buyButton.setBounds(50, 160, 100, 40);
        
        add(titleLabel);
        add(categoryLabel);
        add(priceLabel);
        add(quantityTextLabel);
        add(quantityField);
        add(buyButton);

                
        //50 dari kiri
        //210 dari atas
        //300 panjang komponen
        //30 tinggi komponen
      
        // Label hasil perhitungan
       
        JLabel resultTitleLabel = new JLabel("Total Pembelian:");
        resultTitleLabel.setBounds(50, 210, 300, 30);

        unitPriceLabel = new JLabel("Harga Satuan: -");
        unitPriceLabel.setBounds(50, 240, 300, 30);

        quantityLabel = new JLabel("Jumlah: -");
        quantityLabel.setBounds(50, 270, 300, 30);

        taxLabel = new JLabel("PPN (11%): -");
        taxLabel.setBounds(50, 300, 300, 30);

        finalTotalLabel = new JLabel("Total Harga: -");
        finalTotalLabel.setBounds(50, 330, 300, 30);

        JButton backButton = new JButton("Kembali");
        backButton.setBounds(50, 370, 150, 40);
        
        add(resultTitleLabel);
        add(unitPriceLabel);
        add(quantityLabel);
        add(taxLabel);
        add(finalTotalLabel);
        add(backButton);
        
        

        // Event listeners
        buyButton.addActionListener(e -> calculateTotal());
        backButton.addActionListener(e -> {
            dispose();
            mainPage.setVisible(true);
        });

        setVisible(true);
    }

    private void calculateTotal() {
        try {
            int quantity = Integer.parseInt(quantityField.getText());
            if (quantity <= 0) {
                throw new NumberFormatException();
            }

            double total = pricePerUnit * quantity;
            double tax = total * 0.11;
            double finalTotal = total + tax;

            unitPriceLabel.setText("Harga Satuan: Rp " + pricePerUnit);
            quantityLabel.setText("Jumlah: " + quantity + " pcs");
            taxLabel.setText("PPN (11%): Rp " + (int) tax);
            finalTotalLabel.setText("Total Harga: Rp " + (int) finalTotal);
            
            JButton CheckoutButton = new JButton("Check Out");
            CheckoutButton.setBounds(50, 370, 150, 40);
            add(CheckoutButton);

            quantityField.setText(""); // Kosongkan input setelah pembelian
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Masukkan jumlah yang valid!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
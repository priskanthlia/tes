package kuispbo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainPage extends JFrame {
    private String username, nama;
    private JLabel welcomeLabel, instruksiLabel;
    private JButton beliButton, lanjutButton;
    private JTextField inputNama;
    private String selectedCategory;
    private int selectedCode;

    public MainPage(String username) {
        this.username = username;
        setSize(720, 480);
        setTitle("Main Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Input nama
        JLabel namaLabel = new JLabel("Masukkan Nama:");
        namaLabel.setBounds(160, 20, 120, 30);
        add(namaLabel);

        inputNama = new JTextField();
        inputNama.setBounds(280, 20, 200, 30);
        add(inputNama);

        lanjutButton = new JButton("Lanjut");
        lanjutButton.setBounds(490, 20, 100, 30);
        add(lanjutButton);

        // Label Selamat Datang
        welcomeLabel = new JLabel("", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setBounds(0, 60, 720, 30);
        add(welcomeLabel);

        // Label Instruksi
        instruksiLabel = new JLabel("Silahkan pilih kategori DVD yang ingin dibeli", SwingConstants.CENTER);
        instruksiLabel.setBounds(0, 100, 720, 20);
        instruksiLabel.setVisible(false);
        add(instruksiLabel);

        // Panel tombol kategori DVD
        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        buttonPanel.setBounds(160, 140, 400, 50);
        buttonPanel.setVisible(false);
        add(buttonPanel);

        // Tombol kategori DVD
        JButton anakButton = new JButton("DVD Anak");
        JButton dewasaButton = new JButton("DVD Dewasa");
        JButton lansiaButton = new JButton("DVD Lansia");

        anakButton.addActionListener(new CategoryButtonListener("DVD Anak", 27891));
        dewasaButton.addActionListener(new CategoryButtonListener("DVD Dewasa", 35396));
        lansiaButton.addActionListener(new CategoryButtonListener("DVD Lansia", 38550));

        buttonPanel.add(anakButton);
        buttonPanel.add(dewasaButton);
        buttonPanel.add(lansiaButton);

        // Tombol Beli
        beliButton = new JButton("Beli");
        beliButton.setBounds(260, 290, 200, 40);
        beliButton.setEnabled(false);
        beliButton.setVisible(false);
        add(beliButton);

        beliButton.addActionListener(e -> {
            if (selectedCategory != null) {
                JOptionPane.showMessageDialog(this, "Anda memilih kategori: " + selectedCategory + " dengan kode: " + selectedCode,
                        "Konfirmasi Pembelian", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // Tombol Logout
        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(260, 340, 200, 40);
        logoutButton.setVisible(false);
        add(logoutButton);

        logoutButton.addActionListener(e -> {
            dispose();
            new MainPage("Guest").setVisible(true);
        });

        // Aksi tombol Lanjut
        lanjutButton.addActionListener(e -> {
            nama = inputNama.getText().trim();
            if (nama.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nama tidak boleh kosong!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            } else {
                welcomeLabel.setText("Selamat Datang, " + nama);
                inputNama.setVisible(false);
                namaLabel.setVisible(false);
                lanjutButton.setVisible(false);
                
                instruksiLabel.setVisible(true);
                buttonPanel.setVisible(true);
                beliButton.setVisible(true);
                logoutButton.setVisible(true);
            }
        });

        setVisible(true);
    }

    private class CategoryButtonListener implements ActionListener {
        private String category;
        private int code;

        public CategoryButtonListener(String category, int code) {
            this.category = category;
            this.code = code;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            selectedCategory = category;
            selectedCode = code;
            instruksiLabel.setText("Anda memilih kategori: " + category);
            beliButton.setEnabled(true);
        }
    }

    public static void main(String[] args) {
        new MainPage("Guest");
    }
}

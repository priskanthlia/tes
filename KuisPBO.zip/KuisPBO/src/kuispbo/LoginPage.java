/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kuispbo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class LoginPage extends JFrame implements ActionListener{
    //instansiasi komponen GUI
   JLabel tulisan = new JLabel("Login Page");
   
   JLabel usernameLabel = new JLabel("Username : ",SwingConstants.CENTER);
   JLabel passwordLabel = new JLabel("Password : ",SwingConstants.CENTER);
   
   JTextField usernameTextField = new JTextField();
   JPasswordField passwordTextField = new JPasswordField();
   
   JButton tombolLogin = new JButton("Login");
   JButton tombolReset = new JButton("Reset");
   
    LoginPage (){
        setVisible(true);
        setSize(720,480);
        setTitle("Login Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        
        //add komponen GUI ke frame
        add(tulisan);
        
        add(usernameLabel);
        add(passwordLabel);
        
        add(usernameTextField);
        add(passwordTextField);
        
        add(tombolLogin);
        add(tombolReset);
        
        //set posisi komponen GUI di frame
        
        //210 dari kiri
        //20 dari atas
        //150 panjang komponen
        //24 tinggi komponen
        //set posisi komponen GUI di frame
        tulisan.setBounds(210,20,150,24);
        
        usernameLabel.setBounds(20,84,440,12);
        passwordLabel.setBounds(20,152,440,12);
        
        usernameTextField.setBounds(18,100,440,32);
        passwordTextField.setBounds(18,170,440,32);
        
        tombolLogin.setBounds(50,220,200,32);
        tombolReset.setBounds(50,280,200,32);
       
        tombolLogin.addActionListener(this);
        tombolReset.addActionListener(this);
        
    }
    
    //ini event handling, isinya backend
    @Override
    public void actionPerformed(ActionEvent e){
        try{
            if (e.getSource() == tombolLogin){
                //kode yang akan dijalankan jika kita klik tombol login
                String username = usernameTextField.getText();
                char[] passChar = passwordTextField.getPassword();
                String password = new String(passChar);
                
                //cek username dan password
                if(username.equals("123230055") && password.equals(new StringBuilder(username).reverse().toString())){
                    //kode yang akan dijalankan kalau username dan password sesuai
                    System.out.println("Sukses");
                    
                    new MainPage(username); //membuka frame mainpage
                    this.dispose();
                    
                }else {
                    //kode yang akan dijalankan kalau username dan password tidak sesuai
                    JOptionPane.showMessageDialog(this, "Username atau password salah");
                    
//                    new HomePage(username);
                }
                
            }else if(e.getSource() == tombolReset){
                //kode yang akan dijalankan jika kita klik tombol reset
                usernameTextField.setText("");
                passwordTextField.setText("");
                
            }
            
        }catch(Exception error){
        
        }
    }
}
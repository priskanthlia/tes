package View;

import javax.swing.JOptionPane;

public class ErrorHandler {

    public static void showError(String message) {
        JOptionPane.showMessageDialog(null, "Error: " + message, "Terjadi Kesalahan", JOptionPane.ERROR_MESSAGE);
    }

    public static void showInfo(String message) {
        JOptionPane.showMessageDialog(null, message, "Informasi", JOptionPane.INFORMATION_MESSAGE);
    }
}

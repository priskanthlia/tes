package View;

import Controller.LoginController;

import javax.swing.*;
import java.awt.*;

public class LoginPage extends JFrame {
    JTextField tfUsername;
    JPasswordField pfPassword;
    JButton btnLogin;

    public LoginPage() {
        setTitle("Login Page");
        setSize(400, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Background panel
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(187, 222, 251)); // Light Blue

        JLabel title = new JLabel("Login Page");
        title.setFont(new Font("Arial", Font.BOLD, 18));
        title.setBounds(150, 20, 200, 25);

        JLabel lblUsername = new JLabel("Username :");
        lblUsername.setFont(new Font("Arial", Font.PLAIN, 14));
        lblUsername.setBounds(50, 60, 80, 25);

        tfUsername = new JTextField();
        tfUsername.setBounds(140, 60, 200, 25);

        JLabel lblPassword = new JLabel("Password :");
        lblPassword.setFont(new Font("Arial", Font.PLAIN, 14));
        lblPassword.setBounds(50, 100, 80, 25);

        pfPassword = new JPasswordField();
        pfPassword.setBounds(140, 100, 200, 25);

        btnLogin = new JButton("Login");
        btnLogin.setBounds(150, 150, 100, 30);
        btnLogin.setBackground(new Color(255, 179, 71)); // Orange
        btnLogin.setFocusPainted(false);

        btnLogin.addActionListener(e -> {
        String username = tfUsername.getText();
        String password = new String(pfPassword.getPassword());

        if (LoginController.login(username, password)) {
            try {
                new InputDataPage().setVisible(true);
                dispose();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, 
                    "Gagal membuka halaman berikutnya:\n" + ex.toString(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "Username atau password salah!", 
                "Login Gagal", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(title);
        panel.add(lblUsername);
        panel.add(tfUsername);
        panel.add(lblPassword);
        panel.add(pfPassword);
        panel.add(btnLogin);

        add(panel);
    }
}

package View;

import Controller.PenginapanController;
import javax.swing.*;
import java.awt.*;

public class Update extends JFrame {
    JTextField tfNama, tfKontak, tfDurasi;
    JComboBox<String> cbRuang, cbStatus;
    JButton btnUpdate;
    int id;

    PenginapanController controller = new PenginapanController();

    public Update(int id) {
        this.id = id;
        setTitle("Update Penyewa");
        setSize(350, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(40, 40, 40));

        JLabel[] labels = {
            new JLabel("Nama"), new JLabel("Kontak"),
            new JLabel("Ruang"), new JLabel("Durasi"),
            new JLabel("Status")
        };

        tfNama = new JTextField();
        tfKontak = new JTextField();
        tfDurasi = new JTextField();
        cbRuang = new JComboBox<>(new String[]{"A1", "A2", "A3", "B1", "B2"});
        cbStatus = new JComboBox<>(new String[]{"Paid", "Not Paid"});

        JComponent[] inputs = {tfNama, tfKontak, cbRuang, tfDurasi, cbStatus};

        int y = 30;
        for (int i = 0; i < labels.length; i++) {
            labels[i].setBounds(30, y, 100, 25);
            labels[i].setForeground(Color.WHITE);
            inputs[i].setBounds(130, y, 170, 25);
            add(labels[i]);
            add(inputs[i]);
            y += 40;
        }

        btnUpdate = new JButton("Update");
        btnUpdate.setBounds(120, y + 10, 100, 30);
        btnUpdate.setBackground(new Color(255, 179, 71));
        add(btnUpdate);

        btnUpdate.addActionListener(e -> {
            controller.updatePenyewa(
                id,
                tfNama.getText(),
                tfKontak.getText(),
                cbRuang.getSelectedItem().toString(),
                Integer.parseInt(tfDurasi.getText()),
                cbStatus.getSelectedItem().toString()
            );
            new InputDataPage().setVisible(true);
            dispose();
        });
    }
}
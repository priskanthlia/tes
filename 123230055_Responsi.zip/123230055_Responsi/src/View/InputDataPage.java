package View;

import Controller.PenginapanController;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class InputDataPage extends JFrame {
    JTextField tfNama, tfKontak, tfDurasi;
    JComboBox<String> cbRuang, cbStatus;
    JTable table;
    DefaultTableModel model;
    JButton btnTambah, btnHapus, btnEdit, btnBayar;

    PenginapanController controller = new PenginapanController();

    public InputDataPage() {
        setTitle("Data Penginapan");
        setSize(800, 500);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(20, 20, 20));

        JLabel lblNama = new JLabel("Nama");
        JLabel lblKontak = new JLabel("Kontak");
        JLabel lblRuang = new JLabel("Ruang");
        JLabel lblDurasi = new JLabel("Durasi");
        JLabel lblStatus = new JLabel("Status");

        tfNama = new JTextField();
        tfKontak = new JTextField();
        tfDurasi = new JTextField();
        cbRuang = new JComboBox<>(new String[]{"A1", "A2", "A3", "B1", "B2"});
        cbStatus = new JComboBox<>(new String[]{"Paid", "Not Paid"});

        Font font = new Font("Arial", Font.PLAIN, 14);
        Color fg = Color.WHITE;

        JComponent[] components = {lblNama, lblKontak, lblRuang, lblDurasi, lblStatus,
                                tfNama, tfKontak, cbRuang, tfDurasi, cbStatus};

        int x = 30, y = 20;
        for (int i = 0; i < components.length; i++) {
            JComponent c = components[i];
            c.setBounds(x, y, 150, 30);
            c.setFont(font);
            if (c instanceof JLabel) c.setForeground(fg);
            add(c);
            y += 40;
        }

        btnTambah = new JButton("Tambah");
        btnEdit = new JButton("Edit");
        btnBayar = new JButton("Bayar");
        btnHapus = new JButton("Hapus");

        JButton[] buttons = {btnTambah, btnEdit, btnBayar, btnHapus};
        int bx = 220, by = 20;
        for (JButton btn : buttons) {
            btn.setBounds(bx, by, 100, 30);
            btn.setBackground(new Color(255, 179, 71));
            btn.setFocusPainted(false);
            add(btn);
            by += 40;
        }

        model = controller.getAllPenyewa();
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(30, 250, 720, 200);
        add(scrollPane);

        btnTambah.addActionListener(e -> {
            controller.insertPenyewa(
                tfNama.getText(),
                tfKontak.getText(),
                cbRuang.getSelectedItem().toString(),
                Integer.parseInt(tfDurasi.getText()),
                cbStatus.getSelectedItem().toString()
            );
            refreshTable();
        });

        btnEdit.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int id = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
                new Update(id).setVisible(true);
                dispose();
            }
        });

        btnBayar.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int id = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
                controller.updateStatus(id, "Paid");
                refreshTable();
            }
        });

        btnHapus.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int id = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
                controller.deletePenyewa(id);
                refreshTable();
            }
        });
    }

    private void refreshTable() {
        model.setRowCount(0);
        DefaultTableModel newModel = controller.getAllPenyewa();
        for (int i = 0; i < newModel.getRowCount(); i++) {
            model.addRow(new Object[]{
                newModel.getValueAt(i, 0),
                newModel.getValueAt(i, 1),
                newModel.getValueAt(i, 2),
                newModel.getValueAt(i, 3),
                newModel.getValueAt(i, 4),
                newModel.getValueAt(i, 5),
                newModel.getValueAt(i, 6)
            });
        }
    }
}
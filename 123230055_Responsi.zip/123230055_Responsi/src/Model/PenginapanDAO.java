package Model;

import Model.Connector;
import java.sql.*;
import java.util.ArrayList;

public class PenginapanDAO {
    Connection conn = Connector.Connect();

    public ArrayList<Penyewa> getAllPenyewa() {
        ArrayList<Penyewa> list = new ArrayList<>();
        try {
            String query = "SELECT * FROM penyewa";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                list.add(new Penyewa(
                        rs.getInt("id"),
                        rs.getString("nama"),
                        rs.getString("kontak"),
                        rs.getString("ruang"),
                        rs.getInt("durasi"),
                        rs.getInt("total_harga"),
                        rs.getString("status")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public void insertPenyewa(Penyewa penyewa) {
        try {
            String query = "INSERT INTO penyewa (nama, kontak, ruang, durasi, total_harga, status) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, penyewa.getNama());
            pst.setString(2, penyewa.getKontak());
            pst.setString(3, penyewa.getRuang());
            pst.setInt(4, penyewa.getDurasi());
            pst.setInt(5, penyewa.getTotalHarga());
            pst.setString(6, penyewa.getStatus());
            pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updatePenyewa(Penyewa penyewa) {
        try {
            String query = "UPDATE penyewa SET nama=?, kontak=?, ruang=?, durasi=?, total_harga=?, status=? WHERE id=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, penyewa.getNama());
            pst.setString(2, penyewa.getKontak());
            pst.setString(3, penyewa.getRuang());
            pst.setInt(4, penyewa.getDurasi());
            pst.setInt(5, penyewa.getTotalHarga());
            pst.setString(6, penyewa.getStatus());
            pst.setInt(7, penyewa.getId());
            pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePenyewa(int id) {
        try {
            String query = "DELETE FROM penyewa WHERE id=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setInt(1, id);
            pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Model.Connector;
import java.sql.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Harga {

    public static int getHarga(String ruang) {
        int harga = 0;
        try {
            Connection conn = Connector.Connect();
            String query = "SELECT harga FROM kamar WHERE nama = ?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, ruang);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                harga = rs.getInt("harga");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return harga;
    }

    public static int hitungTotalHarga(String ruang, int durasi) {
        return getHarga(ruang) * durasi;
    }
}

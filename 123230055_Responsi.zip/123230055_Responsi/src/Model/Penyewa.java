package Model;

public class Penyewa {
    private int id;
    private String nama;
    private String kontak;
    private String ruang;
    private int durasi;
    private int totalHarga;
    private String status;

    public Penyewa(int id, String nama, String kontak, String ruang, int durasi, int totalHarga, String status) {
        this.id = id;
        this.nama = nama;
        this.kontak = kontak;
        this.ruang = ruang;
        this.durasi = durasi;
        this.totalHarga = totalHarga;
        this.status = status;
    }

    // Getter dan Setter
    public int getId() { return id; }
    public String getNama() { return nama; }
    public String getKontak() { return kontak; }
    public String getRuang() { return ruang; }
    public int getDurasi() { return durasi; }
    public int getTotalHarga() { return totalHarga; }
    public String getStatus() { return status; }

    public void setStatus(String status) {
        this.status = status;
    }
}

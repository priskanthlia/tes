package Controller;

import Model.Connector;
import java.sql.*;
import javax.swing.JOptionPane;

public class LoginController {

    public static boolean login(String username, String password) {
    Connection conn = Connector.Connect();

    try {
        String query = "SELECT * FROM admin WHERE username = ? AND password = ?";
        PreparedStatement pst = conn.prepareStatement(query);
        pst.setString(1, username);
        pst.setString(2, password);

        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            return true; // Login successful
        } else {
            JOptionPane.showMessageDialog(null, "Username atau Password salah!", "Login Gagal", JOptionPane.ERROR_MESSAGE);
            return false; // Login failed
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Terjadi kesalahan koneksi database!", "Error", JOptionPane.ERROR_MESSAGE);
        return false;
        }
    } }
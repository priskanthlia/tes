package Controller;

import Model.Connector;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class PenginapanController {

    Connection conn = Connector.Connect();

    public void insertPenyewa(String nama, String kontak, String ruang, int durasi, String status) {
        try {
            int harga = getHargaRuang(ruang);
            int total = harga * durasi;

            String query = "INSERT INTO penyewa (nama, kontak, ruang, durasi, total_harga, status) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, nama);
            pst.setString(2, kontak);
            pst.setString(3, ruang);
            pst.setInt(4, durasi);
            pst.setInt(5, total);
            pst.setString(6, status);
            pst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int getHargaRuang(String ruang) {
        int harga = 0;
        try {
            String query = "SELECT harga FROM kamar WHERE nama = ?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, ruang);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                harga = rs.getInt("harga");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return harga;
    }

    public DefaultTableModel getAllPenyewa() {
        DefaultTableModel model = new DefaultTableModel(
            new String[] {"ID", "Nama", "Kontak", "Ruang", "Durasi", "Total Harga", "Status"}, 0);
        try {
            String query = "SELECT * FROM penyewa";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nama"),
                    rs.getString("kontak"),
                    rs.getString("ruang"),
                    rs.getInt("durasi"),
                    rs.getInt("total_harga"),
                    rs.getString("status")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return model;
    }

    public void updateStatus(int id, String newStatus) {
        try {
            String query = "UPDATE penyewa SET status = ? WHERE id = ?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, newStatus);
            pst.setInt(2, id);
            pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePenyewa(int id) {
        try {
            String query = "DELETE FROM penyewa WHERE id = ?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setInt(1, id);
            pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updatePenyewa(int id, String nama, String kontak, String ruang, int durasi, String status) {
        try {
            int harga = getHargaRuang(ruang);
            int total = harga * durasi;

            String query = "UPDATE penyewa SET nama = ?, kontak = ?, ruang = ?, durasi = ?, total_harga = ?, status = ? WHERE id = ?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, nama);
            pst.setString(2, kontak);
            pst.setString(3, ruang);
            pst.setInt(4, durasi);
            pst.setInt(5, total);
            pst.setString(6, status);
            pst.setInt(7, id);
            pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
